CREATE TABLE `tipo` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `id_tipo` INTEGER,
    `desc_tipo` VARCHAR(50) NOT NULL
);
