package com.example.consumocombustivel2

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Consumocombustivel2Application

fun main(args: Array<String>) {
	runApplication<Consumocombustivel2Application>(*args)
}
