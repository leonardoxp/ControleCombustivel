package com.example.consumocombustivel2.dtos

data class TipoDTO(
    val id_tipo: Int,
    val desc_tipo: String
)
