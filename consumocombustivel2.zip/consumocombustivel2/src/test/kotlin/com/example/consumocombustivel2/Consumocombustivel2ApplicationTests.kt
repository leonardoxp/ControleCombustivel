package com.example.consumocombustivel2

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Consumocombustivel2ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
